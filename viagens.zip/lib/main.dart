import 'package:flutter/material.dart';
import 'part1.dart';
import 'part2.dart';
import 'part3.dart';
import 'part4.dart';
import 'part5.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        // useMaterial3: false,
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // O AppBar é a barra que fica no topo do aplicativo.
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text(
          'Viagens',
          style: TextStyle(color: Colors.white),
        ),
      ),

      // O SingleChildScrollView é um componente do Flutter que permite que o usuário role a tela para cima e para baixo quando o conteúdo é maior que o espaço disponível.
      body: SingleChildScrollView(
        // serve para colocar um componente dentro de outro
        child: Column(
          children: [
            const ImagemColiseu(),
            const IconesSite(),
            const TextoSite(),
            const Pessoastexto(),
            const SizedBox(height: 15),
            const PessoasPerfil(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
