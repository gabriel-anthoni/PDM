import 'package:flutter/material.dart';

class Avaliacoes extends StatefulWidget {
  const Avaliacoes({super.key});

  @override
  State<Avaliacoes> createState() => _AvaliacoesState();
}

class _AvaliacoesState extends State<Avaliacoes> {
  int estrelas = 0;

  final TextEditingController comentario = TextEditingController();

  @override
  void dispose() {
    comentario.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Avaliações'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 30),
            const Icon(
              Icons.rate_review,
              size: 70,
              color: Colors.blue,
            ),
            const SizedBox(height: 20),
            const Text(
              'Avalie o Coliseu!',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Quantas estrelas você daria?',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) {
                return IconButton(
                  onPressed: () {
                    setState(() {
                      estrelas = index + 1;
                    });
                  },
                  icon: Icon(
                    Icons.star,
                    color: index < estrelas ? Colors.amber : Colors.grey,
                    size: 35,
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: comentario,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Escreva sua avaliação...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (estrelas == 0 || comentario.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Escolha as estrelas e escreva um comentário!',
                      ),
                    ),
                  );
                  return;
                }

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Avaliação registrada!'),
                  ),
                );

                comentario.clear();

                setState(() {
                  estrelas = 0;
                });
              },
              child: const Text('Enviar avaliação'),
            ),
          ],
        ),
      ),
    );
  }
}
