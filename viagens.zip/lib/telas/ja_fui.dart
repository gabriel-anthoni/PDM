import 'package:flutter/material.dart';

class JaFui extends StatefulWidget {
  const JaFui({super.key});

  @override
  State<JaFui> createState() => _JaFuiState();
}

class _JaFuiState extends State<JaFui> {
  bool visitou = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Já fui'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.check_circle,
              color: Colors.blue,
              size: 80,
            ),
            const SizedBox(height: 20),
            const Text(
              'Você já visitou o Coliseu?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 15),
            const Text(
              'Compartilhe que você já conheceu '
              'esse incrível monumento histórico!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  visitou = !visitou;
                });
              },
              child: Text(
                visitou ? 'Já visitei!' : 'Marcar como visitado',
              ),
            ),
            if (visitou)
              const Padding(
                padding: EdgeInsets.all(15),
                child: Text(
                  'Parabéns! Sua visita foi registrada!',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
