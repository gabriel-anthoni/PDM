import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Compartilhar extends StatelessWidget {
  const Compartilhar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Compartilhar'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.share,
              size: 80,
              color: Colors.blue,
            ),
            const SizedBox(height: 20),
            const Text(
              'Compartilhe o Coliseu!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 15),
            const Text(
              'Mostre esse incrível destino para seus amigos!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () async {
                await Clipboard.setData(
                  const ClipboardData(
                    text: 'https://pt.wikipedia.org/wiki/Coliseu',
                  ),
                );

                if (!context.mounted) return;

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Link copiado com sucesso!'),
                  ),
                );
              },
              icon: const Icon(Icons.copy),
              label: const Text('Copiar link'),
            ),
          ],
        ),
      ),
    );
  }
}
