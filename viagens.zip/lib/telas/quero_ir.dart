import 'package:flutter/material.dart';

class QueroIr extends StatefulWidget {
  const QueroIr({super.key});

  @override
  State<QueroIr> createState() => _QueroIrState();
}

class _QueroIrState extends State<QueroIr> {
  bool interesse = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quero ir'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.flight_takeoff,
              size: 80,
              color: Colors.blue,
            ),
            const SizedBox(height: 20),
            const Text(
              'Quer conhecer o Coliseu?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            const Text(
              'Registre seu interesse em visitar '
              'um dos monumentos mais famosos de Roma!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  interesse = !interesse;
                });

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      interesse
                          ? 'Coliseu adicionado à sua lista!'
                          : 'Coliseu removido da sua lista!',
                    ),
                  ),
                );
              },
              child: Text(
                interesse ? 'Remover interesse' : 'Quero visitar!',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
