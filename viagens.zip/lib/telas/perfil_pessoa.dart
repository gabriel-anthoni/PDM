import 'package:flutter/material.dart';

class PerfilPessoa extends StatelessWidget {
  final String nome;
  final int idade;
  final String cidade;
  final String imagem;
  final String descricao;

  const PerfilPessoa({
    super.key,
    required this.nome,
    required this.idade,
    required this.cidade,
    required this.imagem,
    required this.descricao,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 30),

            // FOTO DO PERFIL
            ClipOval(
              child: imagem.startsWith('http')
                  ? Image.network(
                      imagem,
                      width: 140,
                      height: 140,
                      fit: BoxFit.cover,
                    )
                  : Image.asset(
                      imagem,
                      width: 140,
                      height: 140,
                      fit: BoxFit.cover,
                    ),
            ),

            const SizedBox(height: 15),

            // NOME
            Text(
              nome,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            // IDADE E CIDADE
            Text(
              '$idade anos • $cidade',
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 25),

            // DESCRIÇÃO
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                descricao,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 17,
                  height: 1.5,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // BOTÃO SEGUIR
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Você está seguindo $nome!'),
                  ),
                );
              },
              icon: const Icon(Icons.person_add),
              label: const Text('Seguir'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 35,
                  vertical: 15,
                ),
              ),
            ),

            const SizedBox(height: 30),

            // INFORMAÇÕES ADICIONAIS
            const Divider(),

            const ListTile(
              leading: Icon(Icons.flight_takeoff, color: Colors.blue),
              title: Text('Destino favorito'),
              subtitle: Text('Coliseu - Roma, Itália'),
            ),

            const ListTile(
              leading: Icon(Icons.favorite, color: Colors.red),
              title: Text('Interesse'),
              subtitle: Text('Viagens e turismo'),
            ),
          ],
        ),
      ),
    );
  }
}
