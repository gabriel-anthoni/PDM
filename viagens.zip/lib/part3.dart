import 'package:flutter/material.dart';

class TextoSite extends StatelessWidget {
  const TextoSite({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      // Adicionar espaçamento interno
      padding: const EdgeInsets.all(16),

      child: Text(
        'O Coliseu de Roma é um dos monumentos mais famosos '
        'do mundo. Construído na Roma Antiga, era utilizado '
        'para grandes espetáculos, combates de gladiadores '
        'e eventos públicos. Hoje é um dos principais pontos '
        'turísticos da Itália e recebe milhões de visitantes '
        'todos os anos.',
        style: const TextStyle(
          fontSize: 15,
          color: Colors.black87,
          height: 1.5,
        ),
        textAlign: TextAlign.justify,
      ),
    );
  }
}
