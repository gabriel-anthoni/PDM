import 'package:flutter/material.dart';
import 'telas/perfil_pessoa.dart';

class PessoasPerfil extends StatelessWidget {
  const PessoasPerfil({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          // PESSOA 1
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PerfilPessoa(
                      nome: 'Lucas',
                      idade: 24,
                      cidade: 'São Paulo',
                      imagem: 'https://i.pravatar.cc/300?img=12',
                      descricao: 'Gosto de viajar, conhecer '
                          'novas culturas e explorar lugares históricos.',
                    ),
                  ),
                );
              },
              child: ClipOval(
                child: Image.network(
                  'https://i.pravatar.cc/300?img=12',
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          const SizedBox(width: 10),

          // PESSOA 2
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PerfilPessoa(
                      nome: 'Mariana',
                      idade: 22,
                      cidade: 'Rio de Janeiro',
                      imagem: 'https://i.pravatar.cc/300?img=47',
                      descricao: 'Sou apaixonada por fotografia '
                          'e adoro conhecer monumentos históricos.',
                    ),
                  ),
                );
              },
              child: ClipOval(
                child: Image.network(
                  'https://i.pravatar.cc/300?img=47',
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          const SizedBox(width: 10),

          // PESSOA 3
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PerfilPessoa(
                      nome: 'Pedro',
                      idade: 27,
                      cidade: 'Curitiba',
                      imagem: 'https://i.pravatar.cc/300?img=13',
                      descricao: 'Adoro aventuras, conhecer pessoas '
                          'e descobrir novos destinos.',
                    ),
                  ),
                );
              },
              child: ClipOval(
                child: Image.network(
                  'https://i.pravatar.cc/300?img=13',
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          const SizedBox(width: 10),

          // PESSOA 4
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PerfilPessoa(
                      nome: 'Ana',
                      idade: 25,
                      cidade: 'Belo Horizonte',
                      imagem: 'https://i.pravatar.cc/300?img=44',
                      descricao: 'Amo viajar, experimentar comidas '
                          'diferentes e registrar minhas experiências.',
                    ),
                  ),
                );
              },
              child: ClipOval(
                child: Image.network(
                  'https://i.pravatar.cc/300?img=44',
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
