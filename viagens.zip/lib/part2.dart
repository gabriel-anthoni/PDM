import 'package:flutter/material.dart';

import 'telas/quero_ir.dart';
import 'telas/ja_fui.dart';
import 'telas/compartilhar.dart';
import 'telas/avaliacoes.dart';

class IconesSite extends StatelessWidget {
  const IconesSite({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          // BOTÃO QUERO IR
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const QueroIr(),
                  ),
                );
              },
              child: const Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.flight_takeoff,
                      color: Colors.blue,
                      size: 28,
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Quero ir',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // BOTÃO JÁ FUI
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const JaFui(),
                  ),
                );
              },
              child: const Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: Colors.blue,
                      size: 28,
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Já fui',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // BOTÃO COMPARTILHAR
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Compartilhar(),
                  ),
                );
              },
              child: const Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.share,
                      color: Colors.blue,
                      size: 28,
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Compartilhar',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // BOTÃO AVALIAÇÕES
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Avaliacoes(),
                  ),
                );
              },
              child: const Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.star,
                      color: Colors.blue,
                      size: 28,
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Avaliações',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
