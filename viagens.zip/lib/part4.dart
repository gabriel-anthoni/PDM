import 'package:flutter/material.dart';

class Pessoastexto extends StatelessWidget {
  const Pessoastexto({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      // Adicionar espaçamento interno
      padding: const EdgeInsets.symmetric(horizontal: 16),

      child: Row(
        // cada um em um lugar
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Pessoas encontradas',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          Column(
            children: const [
              Icon(
                Icons.filter_list,
                color: Colors.blue,
                size: 28,
              ),
              Text(
                'Filtrar',
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
