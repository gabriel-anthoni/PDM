package com.example.exercicio1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- CÓDIGO DO BOTÃO AQUI ---
        val botao2 = findViewById<Button>(R.id.button2)
        val botao3 = findViewById<Button>(R.id.button3)

        // 1. Para trocar de tela ao clicar:
        botao2.setOnClickListener {

            // 2. Abre a segunda tela
            val intent = Intent(this, tela2::class.java)
            startActivity(intent)
        }

        botao3.setOnClickListener {

            val intent2 = Intent(this, tela3::class.java)
            startActivity(intent2)
        }
    }
}