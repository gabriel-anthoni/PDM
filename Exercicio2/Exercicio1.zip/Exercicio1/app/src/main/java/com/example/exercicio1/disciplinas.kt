package com.example.exercicio1

import android.graphics.Color
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class disciplinas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_disciplinas)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botão Voltar funcional
        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltar)
        btnVoltar?.setOnClickListener {
            finish()
        }

        // Captura todos os TextViews do layout
        val tvSemestre = findViewById<TextView>(R.id.tvSemestreDisciplina)
        val tvNome = findViewById<TextView>(R.id.tvNomeDisciplina)
        val tvDetalhes = findViewById<TextView>(R.id.tvDetalhesDisciplina)
        val tvProfessor = findViewById<TextView>(R.id.tvProfessor)
        val tvNivel = findViewById<TextView>(R.id.tvNivel)
        val tvNumeroAulas = findViewById<TextView>(R.id.tvNumeroAulas)
        val tvPreRequisitos = findViewById<TextView>(R.id.tvPreRequisitos)
        val tvObjetivo = findViewById<TextView>(R.id.tvObjetivo)
        val tvEmenta = findViewById<TextView>(R.id.tvEmenta)

        // Pega os dados enviados pela Intent da tela anterior
        val semestreRecebido = intent.getStringExtra("CH_SEMESTRE")
        val nomeRecebido = intent.getStringExtra("CH_NOME")
        val detalhesRecebidos = intent.getStringExtra("CH_DETALHES")
        val professorRecebido = intent.getStringExtra("CH_PROFESSOR")
        val nivelRecebido = intent.getStringExtra("CH_NIVEL")
        val aulasRecebidas = intent.getStringExtra("CH_AULAS")
        val preReqRecebido = intent.getStringExtra("CH_PREREQ")
        val objetivoRecebido = intent.getStringExtra("CH_OBJETIVO")
        val ementaRecebida = intent.getStringExtra("CH_EMENTA")

        // Preenche os componentes básicos
        tvSemestre.text = semestreRecebido ?: "SEMESTRE"
        tvNome.text = nomeRecebido ?: "Nome da Disciplina"
        tvDetalhes.text = detalhesRecebidos ?: "Carga horária indisponível"
        tvProfessor.text = professorRecebido ?: "A definir"
        tvNivel.text = nivelRecebido ?: "Obrigatória"
        tvNumeroAulas.text = aulasRecebidas ?: "4 aulas semanais"
        tvPreRequisitos.text = preReqRecebido ?: "Nenhum"
        tvObjetivo.text = objetivoRecebido ?: "Objetivo não informado."
        tvEmenta.text = ementaRecebida ?: "Ementa não informada."

        when (semestreRecebido) {
            "1º SEMESTRE" -> {
                // Azul para o 1º Semestre
                tvSemestre.setTextColor(Color.parseColor("#2196F3"))
            }
            "2º SEMESTRE" -> {
                // Verde para o 2º Semestre (ou qualquer outra cor que preferir)
                tvSemestre.setTextColor(Color.parseColor("#4CAF50"))
            }
            else -> {
                // Cor padrão caso venha vazio ou outro semestre
                tvSemestre.setTextColor(Color.parseColor("#FFFFFF"))
            }
        }
    }
}