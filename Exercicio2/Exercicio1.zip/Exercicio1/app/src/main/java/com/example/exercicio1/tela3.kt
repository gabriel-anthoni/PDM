package com.example.exercicio1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class tela3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tela3)

        val mainView = findViewById<android.view.View>(R.id.main)
        mainView?.let { view ->
            ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }

        // Botão Voltar
        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltar)
        btnVoltar?.setOnClickListener {
            finish()
        }

        val card1 = findViewById<CardView>(R.id.card1)
        card1.setOnClickListener {
            val intent = Intent(this, disciplinas::class.java).apply {
                putExtra("CH_SEMESTRE", "1º SEMESTRE")
                putExtra("CH_COR_SEMESTRE", "#2196F3")
                putExtra("CH_NOME", "Algoritmos e Lógica de Programação")
                putExtra("CH_DETALHES", "Carga horária: 80h • Lógica e Sintaxe Básica")
                putExtra("CH_PROFESSOR", "Prof. Carlos Silva")
                putExtra("CH_NIVEL", "Básico • Obrigatória")
                putExtra("CH_AULAS", "4 aulas semanais")
                putExtra("CH_PREREQ", "Nenhum")
                putExtra("CH_OBJETIVO", "Capacitar o aluno a estruturar o pensamento lógico para resolução de problemas computacionais.")
                putExtra("CH_EMENTA", "Lógica de programação, fluxogramas, tipos de dados, estruturas condicionais e de repetição, vetores e matrizes.")
            }
            startActivity(intent)
        }

        val card2 = findViewById<CardView>(R.id.card2)
        card2.setOnClickListener {
            val intent = Intent(this, disciplinas::class.java).apply {
                putExtra("CH_SEMESTRE", "1º SEMESTRE")
                putExtra("CH_COR_SEMESTRE", "#2196F3")
                putExtra("CH_NOME", "Modelagem de Banco de Dados")
                putExtra("CH_DETALHES", "Carga horária: 80h • SQL e Bancos Relacionais")
                putExtra("CH_PROFESSOR", "Profa. Ana Souza")
                putExtra("CH_NIVEL", "Básico • Obrigatória")
                putExtra("CH_AULAS", "4 aulas semanais")
                putExtra("CH_PREREQ", "Nenhum")
                putExtra("CH_OBJETIVO", "Ensinar os conceitos de projeto conceitual, lógico e físico de bancos de dados relacionais.")
                putExtra("CH_EMENTA", "Modelo entidade-relacionamento (MER), normalização, linguagem SQL (DDL, DML) e SGBDs.")
            }
            startActivity(intent)
        }

        val card3 = findViewById<CardView>(R.id.card3)
        card3.setOnClickListener {
            val intent = Intent(this, disciplinas::class.java).apply {
                putExtra("CH_SEMESTRE", "2º SEMESTRE")
                putExtra("CH_COR_SEMESTRE", "#4CAF50")
                putExtra("CH_NOME", "Desenvolvimento Mobile (Android)")
                putExtra("CH_DETALHES", "Carga horária: 80h • Kotlin e Android Studio")
                putExtra("CH_PROFESSOR", "Prof. João Mendes")
                putExtra("CH_NIVEL", "Intermediário • Obrigatória")
                putExtra("CH_AULAS", "4 aulas semanais")
                putExtra("CH_PREREQ", "Algoritmos e Lógica de Programação")
                putExtra("CH_OBJETIVO", "Capacitar o estudante no desenvolvimento de aplicativos nativos para a plataforma Android usando Kotlin.")
                putExtra("CH_EMENTA", "Introdução ao Android Studio, Activities, Intents, Layouts XML, Componentes de UI e ciclo de vida.")
            }
            startActivity(intent)
        }

        val card4 = findViewById<CardView>(R.id.card4)
        card4.setOnClickListener {
            val intent = Intent(this, disciplinas::class.java).apply {
                putExtra("CH_SEMESTRE", "2º SEMESTRE")
                putExtra("CH_COR_SEMESTRE", "#4CAF50")
                putExtra("CH_NOME", "Engenharia de Software")
                putExtra("CH_DETALHES", "Carga horária: 60h • Metodologias Ágeis e UML")
                putExtra("CH_PROFESSOR", "Profa. Mariana Lima")
                putExtra("CH_NIVEL", "Intermediário • Obrigatória")
                putExtra("CH_AULAS", "3 aulas semanais")
                putExtra("CH_PREREQ", "Nenhum")
                putExtra("CH_OBJETIVO", "Compreender os processos de desenvolvimento de software sob uma perspectiva estruturada e ágil.")
                putExtra("CH_EMENTA", "Ciclo de vida do software, Scrum, Kanban, diagramas UML, testes de software e qualidade.")
            }
            startActivity(intent)
        }
    }
}