package com.example.exercicio1

import android.content.Intent
import android.os.Bundle
import android.widget.Button // Import do Button adicionado
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class tela2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela2)

        val botaoimg = findViewById<ImageButton>(R.id.imagebutton)

        // CORREÇÃO: Mudar de ImageButton para Button
        val botao_d = findViewById<Button>(R.id.button)

        botaoimg.setOnClickListener {
            finish()
        }

        botao_d.setOnClickListener {
            val intent = Intent(this, tela3::class.java)
            startActivity(intent)
        }
    }
}